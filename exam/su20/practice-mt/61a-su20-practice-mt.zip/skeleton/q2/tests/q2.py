test = {'name': 'q2',
 'points': 6,
 'suites': [{'cases': [{'code': '>>> guesser = make_guess(10)\n'
                                '\n'
                                '>>> guess1 = guesser(6)\n'
                                '\n'
                                '>>> guess2 = guess1(7)\n'
                                '\n'
                                '>>> guess3 = guess2(8)\n'
                                '\n'
                                '>>> guess3(10)\n'
                                '3\n'
                                '\n'
                                '>>> guess2(10)\n'
                                '2\n'
                                '\n'
                                '>>> a = make_guess(5)(1)(2)(3)(4)(5)\n'
                                '\n'
                                '>>> a\n'
                                '4\n'}],
             'scored': True,
             'setup': 'from q2 import *',
             'type': 'doctest'}]}